# -*- coding: utf-8 -*-
# Module: router
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
"""
# Импорт стандартного модуля для разделения поступающей строки на ключ и значение
from urllib.parse import parse_qsl

# Импорт модуля плагина для создания модели
from .model import ModelRenTv
from .view import View


# Функция переключения поступающий данных
def router(data_string: str) -> None:
    try:
        # Преобразование поступающей строки в словарь
        # parse_qsl - разбирает строку на параметры и их значения
        params_dict: dict = dict(parse_qsl(data_string))
    except TypeError:
        raise TypeError(f'Нельзя представить как словарь: {data_string}!')
    view = View()
    model = ModelRenTv()
    if params_dict:
        if params_dict['router'] == 'rutube':
            view.play(model.rutube(params_dict['data']))
        elif params_dict['router'] == 'platformcraft':
            view.play_w(params_dict['data'])
        elif params_dict['router'] == 'ok':
            view.play(model.ok(params_dict['data']))


        elif params_dict['router'] == "project":
            view.season(model.project(id_=params_dict['data'][0], years=params_dict['data'][1]))


        elif params_dict['router'] == "samye_shokiruiushchie_gipotezy":
            # Вывод списка серий, импортировано из модуля view
            view.season(model.samye_shokiruiushchie_gipotezy())
        elif params_dict['router'] == "tainy_chapman":
            # Вывод списка серий, импортировано из модуля view
            view.season(model.tainy_chapman())



        else:
            raise ValueError(f'Не нашлось нужных ключей: {params_dict}!')
    else:
        view.check_modules()
        # Вывод выбора категории действия, импортировано из модуля view
        main = {
            "category": "Меню",
            "list": model.main()
        }
        view.main(main)
        # view.main(model.main_check())

