# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль создания модели данных для интерфейса KODI.
"""
# Импорт модуля плагина из текущего каталога для запроса данных
from .parser import ParserRenTv


class ModelRenTv:
    __slots__ = []
    _parser = ParserRenTv()

    @staticmethod
    def _null_to_string(check):
        if check is None:
            return ""
        else:
            return check

    @staticmethod
    def _null_to_integer(check):
        if check is None:
            return 0
        else:
            return check

    @staticmethod
    def _cleanhtml(raw_html):
        import re
        return re.sub(re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});'), ' ', raw_html)

    def _season(self, data: list) -> tuple:
        model_list: list = []
        for item in data:
            model: dict = {}
            model["title"]: str = str(self._null_to_string(item["title"]))
            model["premiered"]: str = str(self._null_to_string(item["created_at"].split("T")[0]))
            model["posters"]: str = str(self._null_to_string(item["image"]["url"]))
            model["plot"]: str = str(self._null_to_string(self._cleanhtml(item["description"])))
            if item["config"]["provider"] == "rutube":
                model["player"]: str = item["config"]["rutube"]["id"]
                model["router"]: str = "rutube"
            elif item["config"]["provider"] == "platformcraft":
                model["player"]: str = "http://" + item["config"]["platformcraft"]["list"][0]["cdn_url"]
                model["router"]: str = "platformcraft"
            elif item["config"]["provider"] == "ok":
                model["player"]: str = "https://ok.ru/video/" + item["config"]["ok"]["id"]
                model["router"]: str = "ok"

            # if item["config"]["provider"] == "ok":
            #     model["player"]: str = "https://ok.ru/video/" + item["config"]["ok"]["id"]
            #     model["router"]: str = "ok"
            # else:
            #     continue

            model_list.append(model)
        return tuple(model_list)

    def _seasons(self, id_: int, years: tuple):
        model_list: list = []
        for year in years:
            model_list.extend(self._season(self._parser.season(f"{id_}/{year}")["data"]))
        return tuple(model_list)

    def samye_shokiruiushchie_gipotezy(self) -> dict:
        years: tuple = 446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 446581, 0,
        model: dict = {}
        model["category"]: str = "Самые шокирующие гипотезы"
        model["players"]: tuple = self._seasons(id_=76583, years=years)
        return model

    def tainy_chapman(self) -> dict:
        years: tuple = 446615, 446441, 446072, 445686, 85301, 63330, 36766, 19320, 8644, 446582,
        model: dict = {}
        model["category"]: str = "Тайны Чапман"
        model["players"]: tuple = self._seasons(id_=54823, years=years)
        return model

    def rutube(self, id_: str) -> str:
        return self._parser.rutube(id_)["video_balancer"]["m3u8"]

    def ok(self, link: str) -> str:
        import yt_dlp
        ydl = yt_dlp.YoutubeDL({})
        info = ydl.extract_info(link, download=False)
        return ydl.sanitize_info(info)["formats"][13]["url"]

    def main(self) -> tuple:
        model_list: list = []
        samye_shokiruiushchie_gipotezy: dict = {
            "title": "Самые шокирующие гипотезы",
            "router": "samye_shokiruiushchie_gipotezy",
            "genres": ["Документальные"],
            "plot": "Программа, которая ищет закономерности и параллели в самых невероятных явлениях нашей жизни."
                    "Новые ответы на старые вопросы."
                    "Факты, о которых долго молчали журналисты."
                    "Независимая оценка событий, изменивших мир."
                    "Расследования самых сенсационных историй и свежий взгляд на общеизвестные исторические факты."
                    "Новости из всех областей человеческих знаний и загадки потайных уголков нашего подсознания.",
            "posters": "https://cdn.ren.tv/media/img/9b/75/9b750723af503218e55a8301527a22fc0c7a993c.jpg"
        }
        model_list.append(samye_shokiruiushchie_gipotezy)
        tainy_chapman: dict = {
            "title": "Тайны Чапман",
            "router": "tainy_chapman",
            "genres": ["Документальные"],
            "plot": "Истории о том, как всё устроено на самом деле. Программа ищет ответы на простые и в то же время сложные вопросы."
                    "Почему количество природных катастроф за последние годы выросло в несколько раз?"
                    "Может ли питьевая вода стать причиной глобальной войны?"
                    "Какие опасности таит в себе увлечение здоровым образом жизни?"
                    "Почему лекарств в аптеках становится всё больше, а пользы от них – всё меньше?"
                    "За счёт чего и кого богатеют корпорации?"
                    "Как не попасть в ловушку за собственные деньги?",
            "posters": "https://cdn.ren.tv/media/img/5b/0f/5b0f0e668f0474915ed7043cc8d0d3efaddf35fc.jpg"
        }
        model_list.append(tainy_chapman)
        return tuple(model_list)
