# -*- coding: utf-8 -*-
# Module: addon
# Author: Zeltorix
# Created on: 2023.02.25
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.

"""
from resources.lib import *
