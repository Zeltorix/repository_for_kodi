# -*- coding: utf-8 -*-
# Module: parser
# Author: Zeltorix
# Created on: 2023.03.01
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.
"""
Модуль плагина для KODI 19.x "Matrix" и выше.
Модуль для получения данных с ресурса.
"""
# Стандартные модули
import re
from time import time, sleep
# Не стандартный модуль импортируется в addon.xml как script.module.requests
import requests


class ParserRenTv:
    """
    Клас для получения данных
    """
    __slots__ = []
    _link_api_rentv: str = "/0/ipa/vt.ner//:sptth"[::-1]
    _link_api_rutube: str = "/snoitpo/yalp/ipa/ur.ebutur//:sptth"[::-1]
    _user_agent: str = "plugin for KODI"
    _accept_encoding: str = "gzip"

    def season(self, data: str) -> dict:
        return self._rest_api(f"{self._link_api_rentv}episode/list/{data}")

    def rutube(self, id_: str) -> dict:
        return self._rest_api(self._link_api_rutube + id_)

    def _rest_api(self, link: str, retry: int = 10) -> (dict, str):
        headers = {
            "User-Agent": self._user_agent,
            "Accept": "application/json",
            "Accept-Encoding": self._accept_encoding,
        }
        response = requests.get(link, headers=headers, timeout=5)
        try:
            if response.status_code == 500 | 502 | 503:
                return "Ошибка сервера"
            elif response.status_code == 404:
                return "Произошла смена API"
            elif response.status_code == 200:
                return response.json()
        except ConnectionError:
            if retry:
                sleep(10)
                return self._rest_api(link, retry - 1)
            else:
                return "Что, где, не то с API..."
