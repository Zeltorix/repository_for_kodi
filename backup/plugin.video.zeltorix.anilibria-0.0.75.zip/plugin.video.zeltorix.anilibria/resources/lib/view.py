# -*- coding: utf-8 -*-
# Module: view
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Плагин для KODI 19.x "Matrix" и выше.
"""
# Стандартные модули
import sys
from urllib.parse import urlencode
# Модули KODI
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon


class View:
    __slots__ = []
    # Получите URL-адрес плагина в формате plugin:// значение.
    _url = sys.argv[0]
    # Получить заготовка плагина в виде целого числа.
    _handle = int(sys.argv[1])
    _kodi_version_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])

    def get_setting(self, id_: str) -> str:
        id_a: str = self._url.split("//")[1].split("/")[0]
        return xbmcaddon.Addon(id_a).getSetting(id_)

    @staticmethod
    def check_modules() -> None:
        try:
            xbmcaddon.Addon('script.module.requests')
        except (ModuleNotFoundError, RuntimeError):
            xbmcgui.Dialog().notification(
                heading='Установка библиотеки requests',
                message='script.module.requests',
                icon=xbmcgui.NOTIFICATION_WARNING,
                time=5000)
            xbmc.executebuiltin('RunPlugin("plugin://script.module.requests")')
        try:
            xbmcaddon.Addon('inputstream.adaptive')
        except (ModuleNotFoundError, RuntimeError):
            xbmcgui.Dialog().notification(
                heading='Установка библиотеки inputstream adaptive',
                message='inputstream.adaptive',
                icon=xbmcgui.NOTIFICATION_WARNING,
                time=5000)
            xbmc.executebuiltin('RunPlugin("plugin://inputstream.adaptive")')

    @staticmethod
    def cdn_error() -> None:
        xbmcgui.Dialog().notification(
            heading='Сайт с картинками не доступен',
            message='Сайт с картинка не отвечает',
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=5000)

    def _convert_to_url(self, **kwargs: str) -> str:
        # Преобразование кляча и значения в ссылку данных для дополнения в виде URL
        return '{}?{}'.format(self._url, urlencode(kwargs))

    @staticmethod
    def search() -> str:
        return xbmcgui.Dialog().input(
            'Введите название аниме',
            type=xbmcgui.INPUT_ALPHANUM)

    def play(self, path: str) -> None:
        # Создаю элемент с указанием url для воспроизведения.
        play_item = xbmcgui.ListItem(path=path)
        # Подорожник на пропуск сцен
        play_item.setProperty('inputstream', "inputstream.adaptive")
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # Передача элемента в оболочку проигрывателя Kodi.
        xbmcplugin.setResolvedUrl(handle=self._handle, succeeded=True, listitem=play_item)

    def listing(self, data: dict) -> None:
        # Сортировка элементов отсутствует, т.к. серии идут и так по порядку, а список нового аниме в порядке выхода
        if data["sort"]:
            sort_item = xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE
        else:
            sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'videos')
        category = data["category"]
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, category)
        # Перебор либо списка аниме, либо серий
        for item in data["titles"]:
            # Нужно для дополнения United Search, иначе не отображает название
            list_item = xbmcgui.ListItem(label=item['label'], label2=item['label2'])
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                vinfo.setTitle(item['label'])
                vinfo.setGenres(item['genres'])
                vinfo.setPlot(item['plot'])
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("video")
            else:
                list_item.setInfo('video', {'title': item['label']})
                list_item.setInfo('video', {'genre': item["genre"]})
                list_item.setInfo('video', {'plot': item['plot']})
                list_item.setInfo('video', {'mediatype': 'videos'})
            url = self._convert_to_url(router='title', data=item['id'])
            # list_item.setArt({
            #     'thumb': item['posters'],
            #     'icon': item['posters'],
            #     'fanart': item['posters']})

            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})

            # Нужно для перехода в сезон, иначе не переходит
            is_folder = True
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    def season(self, data: dict) -> None:
        sort_item = xbmcplugin.SORT_METHOD_NONE
        # Установка представления содержимого плагина.
        # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
        # files, songs, artists, albums, movies, tvshows, episodes, musicvideos, videos, images, games
        xbmcplugin.setContent(self._handle, 'episodes')
        # Путь сверху между слешей("/") с добавленным названием
        xbmcplugin.setPluginCategory(self._handle, data['label'])
        # Перебор либо списка аниме, либо серий
        for item in data['players']:
            list_item = xbmcgui.ListItem()
            last = f"[B][COLOR=red]{data['video_type']} {item['episode']}[/COLOR].[/B] {item['title']}"
            no_last = f"[B][COLOR=green]{data['video_type']}[/COLOR][COLOR=yellow] {item['episode']}[/COLOR].[/B] {item['title']}"
            if self._kodi_version_major >= 20:
                vinfo = list_item.getVideoInfoTag()
                if data["total_episodes"] == item['episode']:
                    vinfo.setTitle(last)
                else:
                    vinfo.setTitle(no_last)
                vinfo.setPlot(data["plot"])
                vinfo.setEpisode(item["episode"])
                vinfo.setPremiered(item["premiered"])
                # Это позволяет Kodi выбирать подходящие виды для этого типа контента:
                # video       For normal video
                # set         For a selection of video
                # musicvideo  To define it as music video
                # movie       To define it as normal movie
                # tvshow      If this is it defined as tvshow
                # season      The type is used as a series season
                # episode     The type is used as a series episode
                vinfo.setMediaType("episode")
            else:
                if data["total_episodes"] == item['episode']:
                    list_item.setInfo('video', {
                        'title': last})
                else:
                    list_item.setInfo('video', {
                        'title': no_last})
                list_item.setInfo('video', {'plot': data["plot"]})
                list_item.setInfo('video', {'premiered': item["premiered"]})
                list_item.setInfo('video', {'episode': item["episode"]})
                list_item.setInfo('video', {'mediatype': 'videos'})
                
            # list_item.setArt({'thumb': item['posters'],
            #                   'icon': item['posters'],
            #                   'fanart': item['posters']})

            list_item.setArt({'thumb': item['posters']})
            list_item.setArt({'icon': item['posters']})
            list_item.setArt({'fanart': item['posters']})
            list_item.setProperty('IsPlayable', 'true')

            url = self._convert_to_url(router='play', data=item['player'])
            # Переход внутрь не требуется, можно отключить
            is_folder = False
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(self._handle, sort_item)
        xbmcplugin.endOfDirectory(self._handle)

    # Переработать всё что ниже

    # def titles(self, list_titles: tuple) -> None:
    #     # Установить категорию плагина. Отображается в некоторых скинах как имя текущего раздела.
    #     xbmcplugin.setPluginCategory(self._handle, 'Список аниме')
    #     # Установить содержимое плагина. Это позволяет Kodi выбирать подходящие виды для этого типа контента.
    #     xbmcplugin.setContent(self._handle, 'videos')
    #     for title in list_titles:
    #         list_item = xbmcgui.ListItem(label=title['label'], label2=title['label2'])
    #         # Установите графику (миниатюру, фан-арт, баннер, постер, пейзаж и т. д.) для элемента списка.
    #         # Здесь мы используем одно и то же изображение для всех элементов для простоты.
    #         # В реальном плагине вам нужно настроить каждое изображение соответствующим образом.
    #         list_item.setArt({'thumb': title['posters'],
    #                           'icon': title['posters'],
    #                           'fanart': title['posters']})
    #         # Установить дополнительную информацию для элемента списка.
    #         # Здесь мы используем имя категории для обоих свойств для простоты.
    #         # setInfo позволяет установить различную информацию для элемента.
    #         # 'mediatype' необходим для того, чтобы скин корректно отображал информацию для этого ListItem.
    #         list_item.setInfo('video', {
    #             'title': title['label'],
    #             'genre': title['genre'],
    #             'plot': title['plot'],
    #             'mediatype': 'video'})
    #         # Создать URL для рекурсивного вызова плагина.
    #         # Пример: plugin://plugin.video.example/?action=listing&category=Animals
    #         url = self._convert_to_url(router='title', data=title['id'])
    #         # is_folder = True means that this item opens a sub-list of lower level items.
    #         is_folder = True
    #         # Add our item to the Kodi virtual folder listing.
    #         xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
    #     # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    #     # SORT_METHOD_NONE
    #     # SORT_METHOD_LABEL_IGNORE_THE
    #     xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
    #     # Finish creating a virtual folder.
    #     xbmcplugin.endOfDirectory(self._handle)

    def main(self) -> None:
        """
        Главное меню
        """
        # Установите содержимое плагина. Это позволяет Kodi выбирать подходящие виды для этого типа контента.
        xbmcplugin.setContent(self._handle, 'videos')
        # Установите категорию плагина. Он отображается в некоторых скинах как название текущего раздела.
        xbmcplugin.setPluginCategory(self._handle, 'Меню')
        categories = [
            {
                'name': "Новые реализы",
                'preview': ""
            },
            {
                'name': "Случайное аниме",
                'preview': ""
            },
            {
                'name': "Все аниме",
                'preview': ""
            },
            {
                'name': "Поиск",
                'preview': ""
            },
        ]

        # Просматривайте видеоролики.
        for category in categories:
            # Создайте элемент списка с текстовой меткой и уменьшенным изображением.
            list_item = xbmcgui.ListItem(label=category['name'])
            # Задайте дополнительную информацию для элемента списка.
            # 'mediatype' необходим для того, чтобы скин правильно отображал информацию для этого элемента списка.
            list_item.setInfo('video', {'title': category['name'],
                                        'mediatype': 'video'})
            # Установите графику (миниатюру, фан-арт, баннер, постер, пейзаж и т. д.) для элемента списка.
            # Здесь мы используем одно и то же изображение для всех элементов для простоты.
            # В реальном плагине вам нужно настроить каждое изображение соответствующим образом.
            list_item.setArt({'thumb': category['preview'],
                              'icon': category['preview'],
                              'fanart': category['preview']})
            # Установите для свойства IsPlayable значение true.
            # Это обязательно для воспроизведения видео!
            list_item.setProperty('IsPlayable', 'true')
            # Создать URL для рекурсивного вызова плагина.
            url = None
            if category['name'] == 'Случайное аниме':
                data = ""
                url = self._convert_to_url(router='random', data=data)
            elif category['name'] == 'Новые реализы':
                data = ""
                url = self._convert_to_url(router='updates', data=data)
            elif category['name'] == 'Все аниме':
                data = ""
                url = self._convert_to_url(router='changes', data=data)
            elif category['name'] == 'Поиск':
                data = ""
                url = self._convert_to_url(router='search', data=data)
            # Добавьте элемент списка в виртуальную папку Kodi.
            # is_folder = False означает, что этот элемент не будет открывать ни один подсписок.
            is_folder = True
            # Добавляем наш элемент в список виртуальных папок Kodi.
            xbmcplugin.addDirectoryItem(self._handle, url, list_item, is_folder)
        # Добавьте метод сортировки элементов виртуальной папки (в алфавитном порядке, игнорируйте статьи)
        xbmcplugin.addSortMethod(self._handle, xbmcplugin.SORT_METHOD_NONE)
        # Завершите создание виртуальной папки.
        xbmcplugin.endOfDirectory(self._handle)
