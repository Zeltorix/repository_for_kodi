# -*- coding: utf-8 -*-
# Module: model
# Author: Zeltorix
# Created on: 2023.01.14
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
"""
Модуль плагина plugin.video.zeltorix.anilibria для KODI 19.x "Matrix" и выше.
Модуль для создания модели данных для интерфейса KODI.
"""
# Стандартные модуль
from datetime import datetime

# Импорт модуля плагина из текущего каталога для запроса данных
from .parser import ParserAniLibria
from .view import View


class ModelAniLibria:
    __slots__ = []
    _anilibria = ParserAniLibria()
    _cdn: str = _anilibria.cdn()

    @staticmethod
    def _null_to_string(check):
        if check is None:
            return ""
        else:
            return check

    @staticmethod
    def _null_to_integer(check):
        if check is None:
            return 0
        else:
            return check

    def _title_normalise(self, item: dict) -> dict:
        model: dict = dict()
        posters: str = str(f"{self._cdn}{item['posters']['original']['url']}")
        model["label"]: str = str(self._null_to_string(item["names"]["ru"]))
        model["label2"]: str = str(self._null_to_string(item["names"]["en"]))
        model["alternative"]: str = str(self._null_to_string(item["names"]["alternative"]))
        model["total_episodes"]: int = int(self._null_to_integer(item["type"]["episodes"]))
        model["video_type"]: str = self._null_to_string(item["type"]["string"])
        model["last"]: int = int(self._null_to_integer(item["player"]["episodes"]["last"]))
        model["plot"]: str = str(self._null_to_string(item["description"]))
        model["plotoutline"]: str = str(self._null_to_string(item["announce"]))
        model["posters"]: str = posters
        model["players"]: tuple = self._title_season_normalise(item["player"], posters)
        return model

    def _title_season_normalise(self, items: dict, posters: str) -> tuple:
        _size_video = View().get_setting("size_video").lower()
        model_list: list = []
        host: str = "https://" + items["host"]
        if items["list"]:
            for values in items["list"].values():
                model: dict = dict()
                model["episode"]: int = int(self._null_to_integer(values["episode"]))
                model["title"]: str = str(self._null_to_string(values["name"]))
                model["premiered"]: str = datetime.fromtimestamp(values["created_timestamp"]).strftime('%Y-%m-%d')
                if values["preview"]:
                    model["posters"]: str = self._cdn + values["preview"]
                else:
                    model["posters"]: str = posters
                if values["hls"][_size_video]:
                    model["player"]: str = host + values["hls"][_size_video]
                elif values["hls"]["hd"]:
                    model["player"]: str = host + values["hls"]["hd"]
                elif values["hls"]["sd"]:
                    model["player"]: str = host + values["hls"]["sd"]
                elif values["hls"]["fhd"]:
                    model["player"]: str = host + values["hls"]["fhd"]
                model_list.append(model)
        elif items["rutube"]:
            for values in items["rutube"].values():
                model: dict = dict()
                model["episode"]: int = int(self._null_to_integer(values["episode"]))
                model["title"]: str = ""
                model["premiered"]: str = datetime.fromtimestamp(values["created_timestamp"]).strftime('%Y-%m-%d')
                model["posters"]: str = posters
                model["player"]: str = values["rutube_id"]
                model_list.append(model)
        return tuple(model_list)

    def _titles_normalise(self, item: dict) -> dict:
        model: dict = dict()
        model["id"]: str = str(item["id"])
        model["label"]: str = str(self._null_to_string(item["names"]["ru"]))
        model["label2"]: str = str(self._null_to_string(item["names"]["en"]))
        model["posters"]: str = str(f"{self._cdn}{item['posters']['original']['url']}")
        model["genre"]: str = str(" / ".join(item["genres"]) + ".")
        model["genres"]: list = list(item["genres"])
        model["plot"]: str = str(self._null_to_string(item["description"]))
        return model

    def rutube(self, id_: str) -> str:
        return self._anilibria.rutube(id_)["video_balancer"]["m3u8"]

    def updates(self) -> tuple:
        return tuple(self._titles_normalise(item) for item in self._anilibria.updates()["list"])

    def changes(self) -> tuple:
        return tuple(self._titles_normalise(item) for item in self._anilibria.changes()["list"])

    def title(self, title_id: str) -> dict:
        return self._title_normalise(self._anilibria.title(title_id))

    def random(self) -> tuple:
        return tuple([self._titles_normalise(self._anilibria.random())])

    def search(self, titles: str) -> tuple:
        return tuple(self._titles_normalise(item) for item in self._anilibria.search(titles)["list"])

    def genres(self) -> tuple:
        return tuple(self._anilibria.genres())

    def years(self) -> tuple:
        return tuple(self._anilibria.years())

    @staticmethod
    def main() -> tuple:
        main = []

        return tuple(main)
